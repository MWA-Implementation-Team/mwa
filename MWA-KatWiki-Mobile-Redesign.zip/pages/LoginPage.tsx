import { useContext } from 'preact/hooks';
import { ClientContext } from '#src/client/context.js';
import { Page } from '#src/client/pages.js';
import PageShell from './PageShell.js';

export type LoginErrorKey =
    | 'loginInvalidEmail'
    | 'loginSendFailed'
    | 'loginLinkExpired'
    | 'loginWrongCode'
    | 'loginCodeExpired';

type LoginPageProps = {
    errorKey?: LoginErrorKey;
    sentTo?: string;
    sentKind?: 'login' | 'signup';
    goto?: string;
};

export const loginPage: Page<LoginPageProps> = {
    Component: LoginPage,
    title: (t) => t('titleLogin'),
};

function LoginPage({ errorKey, sentTo, sentKind, goto }: LoginPageProps) {
    const { t } = useContext(ClientContext);
    return (
        <PageShell section="login" title={t('loginHeading')} subtitle="welcome to the event ✧">
            {errorKey && <p class="mwa-wiki-note mwa-wiki-note--error" role="alert">{t(errorKey)}</p>}
            <section class="mwa-wiki-panel">
                <div class="mwa-wiki-panel-head"><h2>☆ {sentTo ? t('loginVerifyCode') : t('loginHeading')}</h2></div>
                <div class="mwa-wiki-panel-body">
                    {sentTo ? (
                        <>
                            <p class="mwa-wiki-note" style={{ marginBottom: '14px' }}>
                                {sentKind === 'signup'
                                    ? t('signupSent', { email: sentTo })
                                    : t('loginSent', { email: sentTo })}
                            </p>
                            <form class="mwa-wiki-form" method="POST" action="/auth/verify">
                                <input type="hidden" name="email" value={sentTo} />
                                {goto && <input type="hidden" name="goto" value={goto} />}
                                <div class="mwa-wiki-field">
                                    <label for="mwa-login-code">{t('loginCodePlaceholder')}</label>
                                    <input id="mwa-login-code" type="text" name="code" placeholder={t('loginCodePlaceholder')} autoComplete="one-time-code" inputMode="numeric" required />
                                </div>
                                <button type="submit" class="btn-primary">{t('loginVerifyCode')}</button>
                            </form>
                        </>
                    ) : (
                        <form class="mwa-wiki-form" method="POST">
                            <div class="mwa-wiki-field">
                                <label for="mwa-login-email">{t('loginEmail')}</label>
                                <input id="mwa-login-email" type="email" name="email" placeholder={t('loginEmail')} autoComplete="email" required />
                            </div>
                            <button type="submit" class="btn-primary">{t('loginSendLink')}</button>
                        </form>
                    )}
                </div>
            </section>
        </PageShell>
    );
}
