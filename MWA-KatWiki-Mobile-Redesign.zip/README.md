# MWA kat/wiki mobile-first redesign

This package updates **all ten supplied TSX pages** and adds a shared `PageShell.tsx`. It uses your existing CSS design tokens and button styles, but brings in the *visual direction* of https://vafelkis.github.io/kat/wiki/: starry deep-purple background, neon borders, subtle text glow, a centered logo, old-web text navigation and compact wiki sections.

The earlier three-column desktop dashboard layout has been removed. This design starts with one column at phone widths (320–430px), then gains wider grids on bigger displays.

## Installing

1. Copy the 11 files in `pages/` into the directory that currently contains your page `.tsx` files. They import `PageShell` through `./PageShell.js`, consistent with the project's existing TypeScript ESM import style.
2. Copy `styles/wiki.css` into your app's stylesheet directory, next to `main.css`.
3. Replace the existing `main.css` with the supplied one **or just append** `@import './wiki.css';` to your existing `main.css` after the button styles. Keep your own existing imports if your project has added more.
4. Your original `tokens.css`, `base.css`, `button.css`, and `header.css` are bundled unchanged for reference. `button.css` is packaged in `styles/components/` because `main.css` references it as `./components/button.css`. Don't duplicate these files if they already exist at the corresponding paths.
5. **Add your actual `logotipas3.png` to the application's static/public root** so it is served from `/logotipas3.png`. The image itself was not uploaded, so it is not in this ZIP. If your asset lives somewhere else, change the `src` inside `PageShell.tsx`.
6. Confirm your route file's URLs for `/app/groups` and `/app/account`; this project’s route mapping wasn't provided. The pages' existing internal form actions, APIs and known activity/leaderboard paths are unchanged.
7. Run your normal project build/typecheck after integration. A full project-level build couldn't be completed without the original repository and its dependencies.

## Preservation notes

- The original `<Header />` stays available in the collapsible **site controls +** section of the shared shell; its links and account/language controls are not removed. The new retro navigation is optimized for touch.
- Group create/delete APIs, login code verification and email form submission, activity cards/details, increment/decrement, user refresh, and SSR props are preserved.
- TODO-only areas remain TODO-only. No new backend/API features were invented.
- All stylesheet overrides are scoped under `.mwa-wiki` to avoid changing unrelated app views.
- The preview uses a labeled placeholder where `logotipas3.png` should appear, since the real image was not attached.

## Source files

`pages/{HomePage,GroupPage,ActivityPage,ActivitiesPage,LoginPage,LandingPage,LeaderboardPage,AccountPage,AdminPage,CasinoPage,PageShell}.tsx`

`styles/{main,tokens,base,wiki}.css`, `styles/components/{button,header}.css`
