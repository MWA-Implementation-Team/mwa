# MWA page redesign

All 10 uploaded TSX page components were refreshed to use a shared, responsive `PageShell.tsx`.

## How to integrate

1. Copy all 11 `.tsx` files into the directory containing your existing page files (likely `src/client/pages/`).
2. Keep their existing filenames; each modified page imports `./PageShell.js`.
3. No additional dependency or stylesheet import is required. `PageShell.tsx` contains the shared CSS.
4. Keep your existing `Header`, `TestCard`, registered activity components, contexts, routes, translations and API files untouched.

## Notes

- Design direction: light white/gray interface, subtle boundaries, red highlights and blue links, based on the visual cues in `layout.html` (which is actually TubeBuddy extension markup).
- Existing route hooks and group create/delete operations, verification flow, user refresh, activity cards/details, counter, logout and leaderboard query navigation are preserved.
- Account, admin, leaderboard and casino remain placeholders; no backend behavior has been invented.
- The `Header` component is not included among supplied files, so its internal styles are unchanged. The reference `layout.html` is not imported because it includes unrelated TubeBuddy markup and scripts.
- Before deploying, run your project's existing typecheck/tests/build; full repository dependencies were not provided.
